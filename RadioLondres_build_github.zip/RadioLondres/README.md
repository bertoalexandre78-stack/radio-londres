# RadioLondres V3 — NTS-1 mkII / logue SDK 2.0

Oscillateur original de synthèse inspiré d'un récepteur AM/ondes courtes des années 1940 soumis à un brouillage intense.

## Contrôles
- A = TUNE : accord / position des battements d'hétérodyne.
- B = JAM : quantité de brouillage.
- Paramètre 3 = VOICE : texture pseudo-vocale synthétique.
- Paramètre 4 = DRIFT : instabilité / dérive du récepteur.
- Paramètre 5 = MODE : BBC / JAMMED / DEAD AIR.
- LFO : pompe lente de réception.

## Cette version
L'archive d'origine était incomplète : `config.mk` déclarait `unit.cc`, mais ce fichier manquait.
Cette version contient le `unit.cc` basé sur le template officiel KORG NTS-1 mkII SDK 2.0.

## Compilation avec le SDK KORG
Placez le dossier `RadioLondres` dans :

    logue-sdk/platform/nts-1_mkii/RadioLondres/

Puis, depuis la racine `logue-sdk` :

    build nts-1_mkii/RadioLondres

Ou, depuis le dossier du projet :

    make
    make install

La sortie finale doit être :

    RadioLondres.nts1mkiiunit

Le SDK KORG documente également la compilation Docker via `run_cmd.sh`.

## Installation sur le NTS-1 mkII
1. Installer KORG KONTROL Editor dédié au NTS-1 mkII.
2. Connecter le NTS-1 mkII en USB et l'allumer.
3. Glisser `RadioLondres.nts1mkiiunit` dans la liste des oscillateurs User Unit.
4. Appuyer sur SEND.
5. Sur le NTS-1 mkII, sélectionner l'oscillateur RadioLondres.

## Son
- BBC : porteuse + fading + hétérodyne + texture vocale synthétique.
- JAMMED : le signal est progressivement noyé dans le brouillage.
- DEAD AIR : réception presque perdue, souffle et parasites dominants.
- Aucun enregistrement historique ni échantillon de voix n'est embarqué.

## Compatibilité
SDK : logue SDK 2.0.0
Cible : Nu:Tekt NTS-1 digital kit mkII
Firmware minimum indiqué par KORG pour les unités SDK 2.0.0 : 1.0.0.

## Important
Le `dev_id` `0x524C4F4E` (RLON) est un identifiant de démonstration. Pour une distribution publique, utilisez un identifiant développeur KORG qui vous est attribué et un `unit_id` qui vous appartient.
