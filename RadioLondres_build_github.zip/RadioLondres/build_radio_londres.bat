@echo off
cd /d "%~dp0..\.."
docker\run_cmd.bat build nts-1_mkii\RadioLondres
