#!/usr/bin/env bash
set -e
SDK_ROOT="$(cd "$(dirname "$0")/../.." && pwd)"
cd "$SDK_ROOT"
./docker/run_cmd.sh build nts-1_mkii/RadioLondres
