##############################################################################
# RadioLondres - NTS-1 mkII / logue SDK 2.0
##############################################################################

PROJECT := RadioLondres
PROJECT_TYPE := osc

UCSRC = header.c
UCXXSRC = unit.cc
UASMSRC =
UASMXSRC =
UINCDIR =
ULIBDIR =
ULIBS = -lm
UDEFS =
