#pragma once

#include "processor.h"
#include "unit_osc.h"

/*
 * RadioLondres V3
 * Original DSP synthesis inspired by the sonic behaviour of 1940s AM/short-wave
 * receivers under severe interference. No historical recording or speech sample
 * is embedded: all signal, noise, heterodyne and voice-like textures are generated.
 *
 * A = TUNE       receiver tuning / heterodyne position
 * B = JAM        hostile interference amount
 * edit params: VOICE, DRIFT, MODE
 */
class Osc : public Processor
{
public:
  uint32_t getBufferSize() const override final { return 0; }

  enum { TUNE=0U, JAM, VOICE, DRIFT, MODE, NUM_PARAMS };
  enum { MODE_BBC=0U, MODE_JAMMED, MODE_DEAD, NUM_MODES };

  struct Params {
    float tune, jam, voice, drift;
    uint32_t mode;
    void reset() { tune=.42f; jam=.70f; voice=.38f; drift=.46f; mode=MODE_JAMMED; }
    Params(){ reset(); }
  };

  void setParameter(uint8_t i, int32_t v) override final {
    switch(i){
      case TUNE:  p_.tune=param_10bit_to_f32(v); break;
      case JAM:   p_.jam=param_10bit_to_f32(v); break;
      case VOICE: p_.voice=param_10bit_to_f32(v); break;
      case DRIFT: p_.drift=param_10bit_to_f32(v); break;
      case MODE:  p_.mode=(uint32_t)v; break;
      default: break;
    }
  }

  const char *getParameterStrValue(uint8_t i,int32_t v) const override final {
    static const char *m[]={"BBC","JAMMED","DEAD AIR"};
    if(i==MODE && v>=0 && v<NUM_MODES) return m[v];
    return nullptr;
  }

  void init(float *) override final {
    p_.reset();
    carrier_=hetero_=hetero2_=0.f;
    voice_=voice2_=0.f;
    fade_=0.f; drift_state_=0.f;
    hiss_lp_=voice_lp_=0.f; crack_=0.f;
    rng_=0x19440618u; note_gain_=1.f; velocity_=1.f;
  }

  void setPitch(float w0){ w0_=w0; }
  void setShapeLfo(float lfo){ lfo_=lfo; }
  void noteOn(uint8_t,uint8_t velo) override final { velocity_=.30f+.70f*(velo/127.f); note_gain_=1.f; }
  void noteOff(uint8_t) override final { note_gain_=.78f; }
  void allNoteOff() override final { note_gain_=0.f; }

  void process(const float *__restrict in,float *__restrict out,uint32_t frames) override final {
    (void)in;
    const Params p=p_;
    float sig=1.f, ng=.18f;
    if(p.mode==MODE_JAMMED){ sig=.70f; ng=.75f; }
    else if(p.mode==MODE_DEAD){ sig=.10f; ng=1.08f; }

    for(const float *end=out+frames; out!=end; ++out){
      rng_ ^= rng_<<13; rng_ ^= rng_>>17; rng_ ^= rng_<<5;
      const float r=((rng_&0xffffu)/32767.5f)-1.f;

      /* Ionospheric fading: slow deep fades + faster flutter. */
      fade_ += .0000045f + .000055f*p_.drift + .000020f*p_.jam;
      if(fade_>=1.f) fade_-=1.f;
      const float f1=.5f+.5f*osc_sinf(fade_);
      const float f2=.5f+.5f*osc_sinf(fade_*9.13f + .7f);
      const float fading=.18f+.82f*(.72f*f1+.28f*f2);

      /* Receiver tuning wander. */
      drift_state_ += r*(.00000008f+.00000115f*p_.drift);
      drift_state_ *= .99993f;

      carrier_ += w0_*(.92f+.08f*osc_sinf(fade_*13.f))+drift_state_;
      carrier_ -= floorf(carrier_);
      const float carrier=osc_sinf(carrier_);

      /* Two beat-frequency whistles, deliberately non-musical. */
      const float hw=.004f + p_.tune*.045f + drift_state_*.35f + lfo_*.0009f;
      hetero_+=hw; hetero_-=floorf(hetero_);
      hetero2_+=.0017f+p_.tune*.020f-drift_state_*.18f;
      hetero2_-=floorf(hetero2_);
      const float h=osc_sinf(hetero_);
      const float h2=osc_sinf(hetero2_);

      /* Narrow receiver noise. */
      hiss_lp_ += (r-hiss_lp_)*.065f;
      const float hiss=r-hiss_lp_*.72f;

      /* Synthetic distant speech/formants, never sampled speech. */
      voice_ += .00022f + p_.voice*.00042f;
      if(voice_>=1.f) voice_-=1.f;
      voice2_ += .00071f + p_.voice*.00055f;
      if(voice2_>=1.f) voice2_-=1.f;
      const float syll=.18f+.82f*fabsf(osc_sinf(voice_));
      const float form=(.62f*osc_sinf(voice2_)+.38f*osc_sinf(voice2_*2.31f))*syll;
      voice_lp_ += (form-voice_lp_)*(.012f+.025f*p_.voice);
      const float ghost=voice_lp_*(.02f+.34f*p_.voice)*(1.f-.72f*p_.jam);

      /* Telegraphic/ignition-like crackles and jammer bursts. */
      float burst=0.f;
      if((rng_&0x7fffu) < (7u+(uint32_t)(110.f*p_.jam))){ crack_=.7f+2.4f*p_.jam; }
      crack_*=.79f;
      burst=r*crack_;

      /* Strong jammer carrier: pulsed heterodyne clusters. */
      const float jam_gate=.5f+.5f*osc_sinf(fade_*3.7f + p_.tune*5.f);
      const float jammer=(.18f*h + .11f*h2 + .08f*osc_sinf(hetero_*3.17f))*p_.jam*(.35f+.65f*jam_gate);

      float radio=carrier*(.16f+.84f*fading) + ghost + h*(.08f+.32f*p_.tune) + h2*(.03f+.13f*p_.tune);
      float x=radio*sig*(1.f-.86f*p_.jam);
      x += hiss*ng*(.035f+.58f*p_.jam);
      x += jammer;
      x += burst*(.06f+.95f*p_.jam);

      /* LFO = unstable ionospheric pump, with extra phase disturbance. */
      const float l=(.5f+.5f*lfo_);
      x *= .72f+.28f*l;
      x = x/(1.f+1.35f*fabsf(x));
      *out=x*.68f*velocity_*note_gain_;
    }
  }

private:
  Params p_;
  float w0_=0.f,lfo_=0.f,carrier_=0.f,hetero_=0.f,hetero2_=0.f;
  float voice_=0.f,voice2_=0.f,fade_=0.f,drift_state_=0.f;
  float hiss_lp_=0.f,voice_lp_=0.f,crack_=0.f,note_gain_=1.f,velocity_=1.f;
  uint32_t rng_=0x19440618u;
};
