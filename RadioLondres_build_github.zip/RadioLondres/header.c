/* RadioLondres V3 - NTS-1 digital kit mkII custom oscillator. */
#include "unit_osc.h"

const __unit_header unit_header_t unit_header = {
    .header_size = sizeof(unit_header_t),
    .target = UNIT_TARGET_PLATFORM | k_unit_module_osc,
    .api = UNIT_API_VERSION,
    .dev_id = 0x524C4F4EU, /* RLON - replace with your registered developer ID for public distribution. */
    .unit_id = 0x0003U,
    .version = 0x00030000U,
    .name = "RadioLondres",
    .num_params = 5,
    .params = {
        {0, 1023, 0, 430, k_unit_param_type_none,    0, 0, 0, {"TUNE"}},
        {0, 1023, 0, 720, k_unit_param_type_none,    0, 0, 0, {"JAM"}},
        {0, 1023, 0, 390, k_unit_param_type_none,    0, 0, 0, {"VOICE"}},
        {0, 1023, 0, 470, k_unit_param_type_none,    0, 0, 0, {"DRIFT"}},
        {0, 2,    0, 1,   k_unit_param_type_strings, 0, 0, 0, {"MODE"}},
        {0, 0, 0, 0, k_unit_param_type_none, 0, 0, 0, {""}},
        {0, 0, 0, 0, k_unit_param_type_none, 0, 0, 0, {""}},
        {0, 0, 0, 0, k_unit_param_type_none, 0, 0, 0, {""}},
        {0, 0, 0, 0, k_unit_param_type_none, 0, 0, 0, {""}},
        {0, 0, 0, 0, k_unit_param_type_none, 0, 0, 0, {""}}
    },
};
